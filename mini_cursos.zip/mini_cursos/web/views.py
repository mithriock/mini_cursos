from django.contrib.auth import logout
from django.http import HttpResponseForbidden
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required

from web.models import Curso, Pertenece, Nota, Evaluacion

@login_required
def home(request):
    cursos = Curso.objects.all()
    cursos_data = []
    for curso in cursos:
        pertenece = Pertenece.objects.filter(user=request.user, curso=curso).first()
        cursos_data.append({
            'curso': curso,
            'pertenece': pertenece,
        })

    es_profesor = request.user.tipo == 'Profesor'
    return render(request, 'home.html', {'cursos_data': cursos_data, 'es_profesor': es_profesor})


def inscribirse(request, curso_id):
    curso = get_object_or_404(Curso, id=curso_id)
    pertenece, created = Pertenece.objects.get_or_create(user=request.user, curso=curso)
    if created:
        pertenece.aprobado = False  # Requiere aprobación manual desde administrador
        pertenece.save()
    return redirect('home')


def curso_detalle(request, curso_id):
    curso = get_object_or_404(Curso, id=curso_id)
    return render(request, 'curso.html', {'curso': curso})


@login_required
def calificar(request, curso_id):
    if request.user.tipo != 'Profesor':
        return HttpResponseForbidden("No tienes permiso para acceder a esta página.")

    curso = get_object_or_404(Curso, id=curso_id)
    evaluaciones = Evaluacion.objects.filter(curso=curso)
    alumnos = Pertenece.objects.filter(curso=curso, aprobado=True)

    alumnos_notas = []
    for alumno in alumnos:
        notas = []
        for evaluacion in evaluaciones:
            nota = Nota.objects.filter(user=alumno.user, evaluacion=evaluacion).first()
            notas.append({
                'evaluacion': evaluacion,
                'nota': nota.nota if nota else '',
            })
        alumnos_notas.append({
            'alumno': alumno.user,
            'notas': notas,
        })

    if request.method == 'POST':
        for alumno in alumnos:
            for evaluacion in evaluaciones:
                nota_key = f"nota_{alumno.user.id}_{evaluacion.id}"
                nueva_nota = request.POST.get(nota_key)
                if nueva_nota is not None and nueva_nota != '':
                    try:
                        nueva_nota_float = float(nueva_nota)
                        Nota.objects.update_or_create(
                            user=alumno.user,
                            evaluacion=evaluacion,
                            defaults={'nota': nueva_nota_float}
                        )
                    except ValueError:
                        pass
        return redirect('calificar', curso_id=curso.id)

    context = {
        'curso': curso,
        'evaluaciones': evaluaciones,
        'alumnos_notas': alumnos_notas,
    }
    return render(request, 'calificar.html', context)


def custom_logout(request):
    logout(request)
    return redirect('login')
