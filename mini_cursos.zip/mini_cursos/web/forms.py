from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser

class StudentRegistrationForm(UserCreationForm):
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'first_name', 'last_name', 'tipo', 'password1', 'password2']
        widgets = {
            'tipo': forms.HiddenInput(),
        }

    def save(self, commit=True):
        user = super().save(commit=False)
        user.tipo = 'Estudiante'
        if commit:
            user.save()
        return user
