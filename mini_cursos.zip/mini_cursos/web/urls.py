from django.urls import path
from django.contrib.auth.views import LoginView, LogoutView
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('accounts/login/', LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', views.custom_logout, name='logout'),
    path('registrarse/<int:curso_id>/', views.inscribirse, name='registrarse' ),
    path('calificar/<int:curso_id>/', views.calificar, name='calificar'),
    path('curso/<int:curso_id>/', views.curso_detalle, name='curso_detalle'),
]