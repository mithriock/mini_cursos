from django.contrib.auth import get_user_model
from django.contrib.auth.models import AbstractUser
from django.db import models


# Create your models here.
class CustomUser(AbstractUser):
    tipo = models.CharField(max_length=45)

    groups = models.ManyToManyField(
        'auth.Group',
        related_name='customuser_set',
        blank=True,
        help_text='The groups this user belongs to.',
        verbose_name='groups',
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='customuser_set',
        blank=True,
        help_text='Specific permissions for this user.',
        verbose_name='user permissions',
    )

    def __str__(self):
        return self.username

class Curso(models.Model):
    name = models.CharField(max_length=64)
    description = models.TextField()

    def __str__(self):
        name = self.name
        return f'curso {name}'


class Evaluacion(models.Model):
    nombre = models.CharField(max_length=50)
    peso = models.IntegerField(default=0)
    curso = models.ForeignKey(Curso, on_delete=models.CASCADE)

    def __str__(self):
        name = self.nombre
        return f'evaluacion {name}'


class Nota(models.Model):
    user = models.ForeignKey(get_user_model(), on_delete=models.CASCADE)
    evaluacion = models.ForeignKey(Evaluacion, on_delete=models.CASCADE)
    nota = models.FloatField(default=0)

    class Meta:
        unique_together = ('user', 'evaluacion')


class Pertenece(models.Model):
    user = models.ForeignKey(get_user_model(), on_delete=models.CASCADE)
    curso = models.ForeignKey(Curso, on_delete=models.CASCADE)
    aprobado = models.BooleanField(null=True)

    class Meta:
        unique_together = ('user', 'curso')
