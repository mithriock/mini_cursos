from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, Curso, Pertenece, Evaluacion, Nota


# Register your models here.
@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        (None, {'fields': ('tipo',)}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        (None, {'fields': ('tipo',)}),
    )
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 'tipo')


@admin.register(Curso)
class CursoAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')
    search_fields = ('name',)
    list_filter = ('name',)


@admin.register(Pertenece)
class PerteneceAdmin(admin.ModelAdmin):
    list_display = ('user', 'curso', 'aprobado')
    list_filter = ('aprobado',)
    search_fields = ('user__username', 'curso__nombre')


@admin.register(Evaluacion)
class EvaluacionesAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'curso', 'peso')
    list_filter = ('curso',)
    search_fields = ('nombre',)

@admin.register(Nota)
class NotaAdmin(admin.ModelAdmin):
    list_display = ('user', 'evaluacion', 'nota')
    list_filter = ('evaluacion', 'user')
    search_fields = ('user__username', 'evaluacion__nombre')
