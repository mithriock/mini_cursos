# crear entorno virtual mediante comandos
python -m venv venv
source ./venv/Scripts/activate

# instalar dependencias
pip install -r requirements.txt

# para exportar dependencias
pip freeze > requirements.txt

# para configurar la Usuario, Clave, host, puerto y BD en archivo settings.py

```
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': "mini_cursos_db",
        'USER': "postgres",
        'PASSWORD': "",
        'HOST': "localhost",
        'PORT': "5432",
        'POOL_OPTIONS': {
            'POOL_SIZE': 10,
            'MAX_OVERFLOW': 10,
            'RECYCLE': 1 * 60 * 60
        }
    },
}
```

# crear migración
python manage.py makemigrations

# para ejecutar migración
python manage.py migrate

# crear usuario de acceso a BD
python manage.py createsuperuser

# Archivo base de datos
mini_cursos_db.sql
